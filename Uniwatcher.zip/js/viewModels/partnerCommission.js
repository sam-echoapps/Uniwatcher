define(['ojs/ojcore',"knockout","jquery","appController"], 
    function (oj,ko,$, app) {

        class PartnerCommission {
            constructor() {
                var self = this;

            }
        }
        return  PartnerCommission;
    }
);